import cors from "cors";

export default function(app) {
  app.use(cors());
};
